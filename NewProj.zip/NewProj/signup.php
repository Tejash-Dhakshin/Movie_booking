<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup</title>
    <link rel="stylesheet" href="pic\indexCss.css">
    <?php
        if(isset($_POST["submit"])){   
            $uname=$_POST["uname"];
            $mail=$_POST["Email"];
            $age=$_POST["age"];
            $pass=$_POST["pass"];
            $serv_name="localhost:3307";
            $user="root";
            $passw="root";
            $db="movie";
            $conn=mysqli_connect($serv_name,$user,$passw,$db)or die("Connection Failed");
            if($conn){
                $sql="select Name , Password from users where (name='$uname')";
                $get=mysqli_query($conn,$sql);
                if($get->num_rows==1){
                    echo "<script>alert('User name is already found');</script>"; 
                }
                else{
                    $query="INSERT INTO `users`(`Name`, `Password`, `age`, `email`) VALUES ('$uname','$pass','$age','$mail')";
                    if(mysqli_query($conn,$query)){
                        echo "<script>alert('Signed up successfully');</script>"; 
                    }
                    else{
                        echo "<script>alert('Sign up Failed');</script>"; 
                    }
                }
            }
        }  
?>
</head>
<body>
<div>   
    <b><h1>Sign UP</h1></b>
    </div>
    <div class="main">
        <form method="post" >
            <h2>Login</h2><br>
            <input type="text" placeholder="UserName" name="uname" id="uname" required><br><br>
            <input type="email" placeholder="E-Mail" name="Email" id="Email" required><br><br>
            <input type="number" min="18" placeholder="age" name="age" id="age" required><br><br>
            <input type="password" placeholder="Password" id="pass" name="pass" requited><br><br>
            <div><input type="submit" name="submit" value="submit"></div><br>
            <b><p>Click Here <a href="index.html">Home</a></p></b>
        </form>
    </div>
</body>
</html>
