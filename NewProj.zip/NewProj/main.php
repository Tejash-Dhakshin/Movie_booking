<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Movie page</title>
    <link rel="stylesheet" href="pic\main.css">
</head>
<body>
    <hr>
    <h1><b><i>KCET CINEMAS</i></b></h1>
    <hr>
    <?php
        session_start();
        $uname= $_SESSION['name'];
        echo "<h2><u>Welcome Mr.$uname</u></h2>";
    ?>
    <div id="on"><h2>Ongoing Movies</h2></div>
    <div>
        <ul style="list-style-type:none" id="pic">
            <li><a href="frozen.html"><img src="pic\frozenPic.jpeg" alt=""></a></li>
            <li><a href="dis.html"><img src="pic\dsi.jpg" alt=""></a></li>
            <li><a href="your.html"><img src="pic/yourPic.jpg" alt=""></a></li>
            <li><a href="spider.html"><img src="pic\spiderPic.jpg" alt=""></a></li>
        </ul>
    </div>
     <div >
        <ul style="list-style-type:none;">
            <div id="im"><a href="index.html"><li>Log Out</li></a></div>
            <div id="im"><a href="yourmovie.php"><li>Your Movies</li></a></div>
        </ul>
    </div>
</body> 
</html>
