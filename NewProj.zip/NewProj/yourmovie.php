<?php
    echo "<link rel='stylesheet' href='pic\ym.css'>";
    session_start();
    $uname=$_SESSION['name'];
    $serv_name="localhost:3307";
    $user="root";
    $passw="root";
    $db="movie";
    $conn=mysqli_connect($serv_name,$user,$passw,$db)or die("Connection Failed");
    if($conn){
        $result1=mysqli_query($conn,"select * from dis_sat where name='$uname'");
        $result2=mysqli_query($conn,"select * from dis_sun where name='$uname'");
        $result3=mysqli_query($conn,"select * from frozen_sat where name='$uname'");
        $result4=mysqli_query($conn,"select * from frozen_sun where name='$uname'");
        $result5=mysqli_query($conn,"select * from name_sat where name='$uname'");
        $result6=mysqli_query($conn,"select * from name_sun where name='$uname'");
        $result7=mysqli_query($conn,"select * from spi_sat where name='$uname'");
        $result8=mysqli_query($conn,"select * from spi_sun where name='$uname'");
        echo "<center>";
        $count=0;
        echo"<h1> Your Movies</h1>";
        while($count<8){
            if($count==0){
                if($result1->num_rows>0){
                    while($row=mysqli_fetch_row($result1)){
                        echo "<table border='1'>";
                        echo "<tr><th><img src='pic/dsi.jpg'></th><td>$row[0]</td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td></tr>";
                        echo "</table>";
                    }
                }
                $count=$count+1;
            }
            if($count==1){
                if($result2->num_rows>0){
                    while($row=mysqli_fetch_row($result2)){
                        echo "<table border='1'>";
                        echo "<tr><th><img src='pic/dsi.jpg'></th><td>$row[0]</td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td></tr>";
                        echo "</table>";
                    }
                }
                $count=$count+1;
            }
            if($count==2){
                if($result3->num_rows>0){
                    while($row=mysqli_fetch_row($result3)){
                        echo "<table border='1'>";
                        echo "<tr><th><img src='pic\frozenPic.jpeg'></th><td>$row[0]</td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td></tr>";
                        echo "</table>";
                    }
                }
                $count=$count+1;
             }
            if($count==3){
                if($result4->num_rows>0){
                    while($row=mysqli_fetch_row($result4)){
                        echo "<table border='1'>";
                        echo "<tr><th><img src='pic\yourPic.jpg'></th><td>$row[0]</td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td></tr>";
                        echo "</table>";
                    }
                }
                $count=$count+1;
             }
            if($count==4){
             if($result5->num_rows>0){
                    while($row=mysqli_fetch_row($result5)){
                        echo "<table border='1'>";
                        echo "<tr><th><img src='pic\yourPic.jpg'></th><td>$row[0]</td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td></tr>";
                        echo "</table>";
                    }
                }
                $count=$count+1;
            }
            if($count==5){
                if($result6->num_rows>0){
                    while($row=mysqli_fetch_row($result6)){
                        echo "<table border='1'>";
                        echo "<tr><th><img src='pic\yourPic.jpg'></th><td>$row[0]</td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td></tr>";
                        echo "</table>";
                    }
                }
                $count=$count+1;
            }
            if($count==6){
                if($result7->num_rows>0){
                    while($row=mysqli_fetch_row($result7)){
                        echo "<table border='1'>";
                        echo "<tr><th><img src='pic\spiderPic.jpg'></th><td>$row[0]</td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td></tr>";
                        echo "</table>";
                    }
                } 
                $count=$count+1;
            }
            if($count==7){
                if($result8->num_rows>0){
                    while($row=mysqli_fetch_row($result8)){
                        echo "<table border='1'>";
                        echo "<tr><th><img src='pic\spiderPic.jpg'></th><td>$row[0]</td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td></tr>";
                        echo "</table>";
                    }
                }
                $count=$count+1;
            }
        echo "</center>";
        }
    }
?>