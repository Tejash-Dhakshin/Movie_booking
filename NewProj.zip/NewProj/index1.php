<?php
if($_SERVER["REQUEST_METHOD"]=="POST"){
    if(isset($_POST["submit"])){   
        $uname=$_POST["uname"];
        $pass=$_POST["pass"];
        $serv_name="localhost:3307";
        $user="root";
        $passw="root";
        $db="movie";
        $conn=mysqli_connect($serv_name,$user,$passw,$db)or die("Connection Failed");
        if($conn){
            $sql="select Name , Password from users where (name='$uname' and Password='$pass')";
            $get=mysqli_query($conn,$sql);
            if($get->num_rows==1){
                session_start();
                $_SESSION['name'] = "$uname";
                header('Location:main.php');
            }
            else{
                echo "<script>alert('User not found');</script>"; 
            }
        }
    }
}   
?>