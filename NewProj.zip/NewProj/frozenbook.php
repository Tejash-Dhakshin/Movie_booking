<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Spider Man Booking</title>
    <link rel="stylesheet" href="pic/css.css">
    <?php   
        if(isset($_POST['Book'])){
            $serv_name="localhost:3307";
            $user="root";
            $passw="root";
            $db="movie";
            $conn=mysqli_connect($serv_name,$user,$passw,$db)or die("Connection Failed");
            if($conn){
                session_start();
                $uname=$_SESSION['name'];
                session_destroy();
                $seats=$_POST['seats'];
                $time=$_POST['day'];
                $total=$seats*150;
                if($time=='sat'){
                    $sql="insert into frozen_sat(Name,Date,Seats,Amount) values('$uname','2023-06-24','$seats','$total');";
                    if(mysqli_query($conn,$sql)){
                        echo "<script>alert('Booking is successful AND Total is $total');</script>";
                    }
                    else{
                        echo "<script>alert('Booking is not successful');</script>";
                    }
                }
                else{
                    $sql="insert into frozen_sun(Name,Date,Seats,Amount) values('$uname','2023-06-24','$seats','$total');";
                    if(mysqli_query($conn,$sql)){
                        echo "<script>alert('Booking is successful AND Total is $total');</script>";
                    }
                    else{
                        echo "<script>alert('Booking is not successful');</script>";
                    }
                }
            }  
        }
    ?>
</head>
<body id="fro">
    <h1>Booking</h1>
    <form method="post">
    <center>    
    <table border="0">
                <tr>
                    <th colspan="2"></th>
                </tr>
                <tr>
                    <th>
                        Name:
                    </th>
                    <td>    
                        <?php
                        session_start();
                        echo $_SESSION['name']
                        ?>
                    </td>
                </tr>
                <tr>
                    <th>
                        Date:
                    </th>
                    <td>
                        <input type="radio" id="sat" name="day" value="sat">
                        <label for="sat">Saterday(24-06-2003)</label><br>
                        <input type="radio" id="sun" name="day" value="sun">
                        <label for="sun">Sunday(25-06-2003)</label><br>
                    </td>
                </tr>
                <tr>
                    <th>per_ticket:</th>
                    <td>150Rs</td>
                </tr>
                <tr>
                    <th>No Of Seats:</th>
                    <td><input type="number" max="51" name='seats' id="seats" value="seats"></td>
                </tr>
                <tr>
                    <center><th colspan="2"><input type="submit" name="Book" value="Book"></th></center>
                </tr>
                <tr>
                    <center><th colspan="2"><a href="main.php"></a></th></center>
                </tr>

        </table>
    </center>
    </form>
    <?php 
        session_destroy();
    ?>
</body>
</html>
